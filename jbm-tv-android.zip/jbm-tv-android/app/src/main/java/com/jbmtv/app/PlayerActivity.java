package com.jbmtv.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

/**
 * Lecteur vidéo natif (ExoPlayer). Remplace la lecture dans la WebView pour une meilleure
 * fiabilité réseau et de meilleures performances que hls.js dans un navigateur intégré.
 */
@UnstableApi
public class PlayerActivity extends Activity {

    public static final String EXTRA_URL = "url";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_IS_LIVE = "is_live";
    public static final String EXTRA_EPG = "epg";
    public static final String EXTRA_DOWNLOADABLE = "downloadable";

    private ExoPlayer player;
    private PlayerView playerView;
    private AudioManager audioManager;
    private String streamUrl;
    private String channelName;
    private boolean downloadable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setBackgroundColor(0xFF000000);
        setContentView(R.layout.activity_player);

        setImmersive();

        streamUrl = getIntent().getStringExtra(EXTRA_URL);
        channelName = getIntent().getStringExtra(EXTRA_NAME);
        boolean isLive = getIntent().getBooleanExtra(EXTRA_IS_LIVE, true);
        String epg = getIntent().getStringExtra(EXTRA_EPG);
        downloadable = getIntent().getBooleanExtra(EXTRA_DOWNLOADABLE, false);

        playerView = findViewById(R.id.player_view);
        TextView tvName = findViewById(R.id.tv_channel_name);
        TextView tvEpg = findViewById(R.id.tv_epg);
        TextView tvLive = findViewById(R.id.tv_live_badge);
        ImageButton btnBack = findViewById(R.id.btn_back);
        ImageButton btnVolume = findViewById(R.id.btn_volume);
        ImageButton btnDownload = findViewById(R.id.btn_download);
        SeekBar volumeSeekBar = findViewById(R.id.volume_seekbar);
        View statusBox = findViewById(R.id.status_box);
        TextView tvStatus = findViewById(R.id.tv_status);
        Button btnRetry = findViewById(R.id.btn_retry);

        tvName.setText(channelName != null ? channelName : "");
        tvLive.setVisibility(isLive ? View.VISIBLE : View.GONE);
        if (epg != null && !epg.isEmpty()) {
            tvEpg.setText(epg);
            tvEpg.setVisibility(View.VISIBLE);
        }
        btnDownload.setVisibility(downloadable ? View.VISIBLE : View.GONE);

        btnBack.setOnClickListener(v -> finish());

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        volumeSeekBar.setMax(maxVolume);
        volumeSeekBar.setProgress(curVolume);
        btnVolume.setOnClickListener(v ->
                volumeSeekBar.setVisibility(volumeSeekBar.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        volumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnDownload.setOnClickListener(v -> startDownload());
        btnRetry.setOnClickListener(v -> {
            statusBox.setVisibility(View.GONE);
            preparePlayer();
        });

        preparePlayer();
    }

    private void setImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void preparePlayer() {
        if (streamUrl == null) return;
        if (player == null) {
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            player.addListener(new Player.Listener() {
                @Override
                public void onPlayerError(PlaybackException error) {
                    View statusBox = findViewById(R.id.status_box);
                    TextView tvStatus = findViewById(R.id.tv_status);
                    tvStatus.setText("Impossible de lire ce flux. Vérifie ta connexion ou réessaie.");
                    statusBox.setVisibility(View.VISIBLE);
                }
            });
        }
        player.setMediaItem(MediaItem.fromUri(Uri.parse(streamUrl)));
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void startDownload() {
        try {
            String filename = (channelName != null ? channelName.replaceAll("[^a-zA-Z0-9_\\-]+", "_") : "video") + ".mp4";
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(streamUrl));
            request.setTitle(filename);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                Toast.makeText(this, "Téléchargement démarré : " + filename, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Échec du téléchargement", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setImmersive();
        if (player != null) player.setPlayWhenReady(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
